function myMiddleName() {
  var mid = document.getElementById("myDIV");
  if (mid.innerHTML === "01000110") {
    mid.innerHTML = "F";
  } else {
    mid.innerHTML = "01000110";
  }
}